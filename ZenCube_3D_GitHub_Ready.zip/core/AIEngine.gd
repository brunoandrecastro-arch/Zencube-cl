class_name AIEngine
extends RefCounted
var rules = RulesEngine.new()
var rng = RandomNumberGenerator.new()
var deadline: int
var nodes: int = 0
var timed_out: bool = false
func _init(seed_value: int = 42) -> void:
	rng.seed = seed_value
func legal(cells: Array) -> Array:
	var out = []
	for i in range(54):
		if cells[i] == 0: out.append(i)
	return out
func evaluate(cells: Array, player: int) -> float:
	var value = 0.0
	for line in rules.lines:
		var a = 0
		var b = 0
		for c in line:
			if cells[c] == player: a += 1
			elif cells[c] != 0: b += 1
		if b == 0: value += [0,1,5,38,10000][a]
		if a == 0: value -= [0,1,6,42,10000][b]
	return value
func ranked(cells: Array, player: int) -> Array:
	var out = []
	for c in legal(cells):
		cells[c] = player
		var score = evaluate(cells,player)
		var threats = rules.threats(cells,player).size()
		if threats >= 2: score += 400
		cells[c] = 3-player
		if rules.threats(cells,3-player).size() >= 2: score += 180
		cells[c] = 0
		out.append([c,score])
	out.sort_custom(func(a,b): return a[1]>b[1])
	return out
func choose(cells_in: Array, player: int, level: int, budget_ms: int = 220) -> int:
	var cells = cells_in.duplicate()
	if not rules.victories(cells,1).is_empty() or not rules.victories(cells,2).is_empty(): return -1
	var moves = legal(cells)
	if moves.is_empty(): return -1
	if level == 0 and rng.randf() < 0.62: return moves[rng.randi_range(0,moves.size()-1)]
	var wins = rules.threats(cells,player)
	if not wins.is_empty(): return wins[0]
	var blocks = rules.threats(cells,3-player)
	if not blocks.is_empty(): return blocks[0]
	deadline = Time.get_ticks_msec()+budget_ms
	nodes = 0
	timed_out = false
	var order = ranked(cells,player)
	var best = order[0][0]
	if level < 2:
		var tied = order.filter(func(x): return x[1] == order[0][1])
		return tied[rng.randi_range(0,tied.size()-1)][0]
	for depth in range(2,5):
		var iteration_best = best
		var score_best = -INF
		for move in order.slice(0,12):
			cells[move[0]] = player
			var score = -search(cells,3-player,depth-1,-INF,INF)
			cells[move[0]] = 0
			if timed_out: break
			if score > score_best:
				score_best = score
				iteration_best = move[0]
		if timed_out: break
		best = iteration_best
	return best
func search(cells: Array, player: int, depth: int, alpha_in: float, beta: float) -> float:
	nodes += 1
	if Time.get_ticks_msec() >= deadline:
		timed_out = true
		return 0
	if not rules.victories(cells,3-player).is_empty(): return -10000-depth
	var wins = rules.threats(cells,player)
	if not wins.is_empty(): return 9000+depth
	var blocks = rules.threats(cells,3-player)
	if blocks.size() >= 2: return -8000-depth
	if depth <= 0: return evaluate(cells,player)
	var order = []
	if blocks.size() == 1: order = [[blocks[0],0]]
	else: order = ranked(cells,player).slice(0,8)
	if order.is_empty(): return 0
	var alpha = alpha_in
	for move in order:
		cells[move[0]] = player
		var value = -search(cells,3-player,depth-1,-beta,-alpha)
		cells[move[0]] = 0
		alpha = maxf(alpha,value)
		if alpha >= beta or timed_out: break
	return alpha
