ZenCube 3D Campaign 2.0 Shadow Realm – 30 original user-supplied pages, WebP compressed without reordering.
Upload this ZIP unchanged to the ROOT of the feature/campaign-2-shadow-realm GitHub branch.
GitHub Actions extracts assets before Godot import.
Do not merge or publish.
